import adminBuilder from '@funnelkit/admin-builder';

adminBuilder.addFilter('wfocu_global_settings_gateway_fields', bool => {
    return true;
});