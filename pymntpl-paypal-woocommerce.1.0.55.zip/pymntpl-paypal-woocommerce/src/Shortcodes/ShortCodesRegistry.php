<?php

namespace PaymentPlugins\WooCommerce\PPCP\Shortcodes;

use PaymentPlugins\WooCommerce\PPCP\Registry\BaseRegistry;

class ShortCodesRegistry extends BaseRegistry {

	protected $registry_id = 'shortcodes';

}