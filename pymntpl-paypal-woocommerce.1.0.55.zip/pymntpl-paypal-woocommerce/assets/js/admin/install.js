import $ from 'jquery';

$(() => {
    $(document.body).WCBackboneModal({
        template: 'wc-ppcp-activation'
    });
});