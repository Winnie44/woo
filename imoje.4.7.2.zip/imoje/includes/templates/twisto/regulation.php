<?php

/** @var string $regulation */
/** @var string $iodo */

?>

<div class="imoje-regulations imoje-twisto-regulations imoje-display-none">
	<span>
	<?php echo esc_html__( 'I agree to provide Twisto S.A. with my transaction details in the imoje payment gateway in order to make an offer to finance my purchases.', 'imoje' ); ?>
	</span>
</div>
