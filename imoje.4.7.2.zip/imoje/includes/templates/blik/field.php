<div class="imoje-blik-code-container">
	<input name="imoje-blik-code" maxlength="6" type="text" required>
</div>
