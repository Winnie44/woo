<?php
defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/vendor/isolated-guzzlehttp-guzzle/isolated-guzzle/vendor/autoload.php';

require_once __DIR__ . '/vendor/isolated-br33f-php-ga4-mp/isolated-php-ga4-mp/vendor/autoload.php';
