<?php return array('dependencies' => array(), 'version' => 'd12f8c68b22976d415e0');
