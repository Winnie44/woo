<?php

defined( 'ABSPATH' ) || exit;
?>

<h3 class="autopay-settings-sidebar__header"><?php _e( 'Detailed documentation of advanced parameters:', 'bm-woocommerce' ) ?></h3>
<a href="https://developers.autopay.pl/online/wtyczki/woocommerce#ustawienia-zaawansowane"
   target="_blank"><?php _e( 'Show documentation', 'bm-woocommerce' ) ?></a>
