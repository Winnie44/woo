<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var string $src
 * @var string $content
 *
 */
?>


<?php if ( ! empty( $content ) ): ?>
	<div class="bm-settings-banner">
		<?php echo $content ?>
	</div>
<?php endif ?>
