<?php

namespace Ilabs\BM_Woocommerce\Controller;

interface Controller_Interface {

	public function handle();
}
