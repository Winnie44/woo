<?php

namespace Ilabs\BM_Woocommerce\Data\Remote\Ga4\Dto;

interface Ga4_Dto_Interface {

	public function to_array(): array;
}
