<?php

namespace Payu\PaymentGateway\Blocks;

class PayuKlarnaBlock extends PayuBlocks {
	protected $name = 'payuklarna';
}
