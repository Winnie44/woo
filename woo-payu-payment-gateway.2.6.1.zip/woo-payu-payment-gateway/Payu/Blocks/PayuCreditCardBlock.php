<?php

namespace Payu\PaymentGateway\Blocks;

class PayuCreditCardBlock extends PayuBlocks {
	protected $name = 'payucreditcard';
}
