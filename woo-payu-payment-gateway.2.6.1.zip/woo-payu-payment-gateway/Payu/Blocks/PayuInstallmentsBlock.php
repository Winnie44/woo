<?php

namespace Payu\PaymentGateway\Blocks;

class PayuInstallmentsBlock extends PayuBlocks {
	protected $name = 'payuinstallments';
}
