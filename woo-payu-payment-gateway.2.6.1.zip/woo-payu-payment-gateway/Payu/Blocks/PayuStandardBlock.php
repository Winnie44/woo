<?php

namespace Payu\PaymentGateway\Blocks;

class PayuStandardBlock extends PayuBlocks {
	protected $name = 'payustandard';
}
