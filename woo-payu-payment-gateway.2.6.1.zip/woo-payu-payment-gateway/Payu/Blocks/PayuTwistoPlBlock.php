<?php

namespace Payu\PaymentGateway\Blocks;

class PayuTwistoPlBlock extends PayuBlocks {
	protected $name = 'payutwistopl';
}
