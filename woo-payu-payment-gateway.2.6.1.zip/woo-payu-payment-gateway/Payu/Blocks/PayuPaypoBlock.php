<?php

namespace Payu\PaymentGateway\Blocks;

class PayuPaypoBlock extends PayuBlocks {
	protected $name = 'payupaypo';
}
