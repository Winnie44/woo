<?php

namespace KrokedilKlarnaPaymentsDeps\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
