<?php return array('dependencies' => array('react', 'wc-components', 'wc-experimental', 'wc-tracks', 'wp-components', 'wp-compose', 'wp-element', 'wp-i18n'), 'version' => '88b3957d023c2f006982');
