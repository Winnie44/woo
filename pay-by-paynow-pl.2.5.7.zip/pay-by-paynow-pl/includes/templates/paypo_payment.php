<p><?php echo __(  'You will be redirected to payment provider page.', 'pay-by-paynow-pl' ); ?></p>
<div class="paynow-data-processing-info">
    <p><?php echo __(  'Secure and fast payments provided by paynow.pl', 'pay-by-paynow-pl' ); ?></p>
</div>

<?php include( 'data_processing_info.php' ); ?>
