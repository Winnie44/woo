<?php

namespace Tpay\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
