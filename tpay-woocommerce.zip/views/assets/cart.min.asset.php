<?php return array('dependencies' => array('jquery'), 'version' => 'f171f3b619bf6a97f990');
