<?php return array('dependencies' => array(), 'version' => '7d92f42b163f774c9c18');
