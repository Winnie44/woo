<?php return array('dependencies' => array('react', 'wc-blocks-checkout', 'wp-plugins'), 'version' => 'd801f6f9f0f63f0a0d0e');
