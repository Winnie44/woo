<?php return array('dependencies' => array('jquery'), 'version' => '517148644fbf62e23eb6');
