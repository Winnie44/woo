<?php return array('dependencies' => array('jquery'), 'version' => '2ead8c6d46eb3adbdb58');
