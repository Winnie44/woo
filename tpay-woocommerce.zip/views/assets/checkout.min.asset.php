<?php return array('dependencies' => array('jquery'), 'version' => 'bf94a7664c991f80bdb9');
