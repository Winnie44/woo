<?php return array('dependencies' => array('jquery'), 'version' => '15659a87ae141b3cccbc');
