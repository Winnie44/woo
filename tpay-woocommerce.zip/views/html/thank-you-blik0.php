<div class="tpay_thank-you">
    <h4>Status płatności</h4>
    <div id="tpay_pending">
        <i class="ti ti-square-rounded-chevrons-right"></i> <span class="tpay_text">Procesujemy twoją płatność</span>
    </div>
    <div id="tpay_success">
        <i class="ti ti-square-rounded-check"></i> <span class="tpay_text">Płatność zakończona sukcesem</span>
    </div>
    <div id="tpay_error">
        <i class="ti ti-square-rounded-x"></i> <span class="tpay_text">Błąd w przetwarzaniu płatności</span>
    </div>
    <div id="tpay_retry-payment-message">
        <p class="tpay_text">Aby spróbować ponownie przekierujemy Cię do bramki płatności Tpay.</p>
        <a class="tpay_text">Ponów proces płatności</a>
    </div>
    <div id="tpay_email-sent-message">
        <p class="tpay_text">Na twój adres e-mail został wysłany link do ponownej próby płatności.</p>
    </div>
</div>
