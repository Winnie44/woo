<?php echo $agreements;
