<?php


namespace PaymentPlugins\WooFunnels\Stripe\Upsell\PaymentGateways;


class GooglePayGateway extends BasePaymentGateway {

	protected $key = 'stripe_googlepay';
}