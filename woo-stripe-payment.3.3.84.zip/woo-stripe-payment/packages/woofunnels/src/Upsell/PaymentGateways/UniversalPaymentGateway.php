<?php


namespace PaymentPlugins\WooFunnels\Stripe\Upsell\PaymentGateways;


class UniversalPaymentGateway extends BasePaymentGateway {

	protected $key = 'stripe_upm';

}