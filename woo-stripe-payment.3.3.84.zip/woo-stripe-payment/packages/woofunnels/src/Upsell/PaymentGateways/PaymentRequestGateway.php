<?php


namespace PaymentPlugins\WooFunnels\Stripe\Upsell\PaymentGateways;


class PaymentRequestGateway extends BasePaymentGateway {

	protected $key = 'stripe_payment_request';
}