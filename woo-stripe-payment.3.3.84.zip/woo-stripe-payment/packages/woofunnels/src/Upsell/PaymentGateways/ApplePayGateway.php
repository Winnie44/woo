<?php


namespace PaymentPlugins\WooFunnels\Stripe\Upsell\PaymentGateways;


class ApplePayGateway extends BasePaymentGateway {

	protected $key = 'stripe_applepay';
}