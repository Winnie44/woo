<?php

namespace PaymentPlugins\WooFunnels\Stripe\Checkout\Compatibility;

class PaymentRequest extends AbstractCompatibility {

	protected $id = 'stripe_payment_request';

}