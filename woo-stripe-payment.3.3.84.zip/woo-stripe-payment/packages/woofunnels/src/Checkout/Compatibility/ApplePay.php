<?php

namespace PaymentPlugins\WooFunnels\Stripe\Checkout\Compatibility;

class ApplePay extends AbstractCompatibility {

	protected $id = 'stripe_applepay';

}