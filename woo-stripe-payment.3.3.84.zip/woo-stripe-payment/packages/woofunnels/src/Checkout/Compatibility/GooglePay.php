<?php

namespace PaymentPlugins\WooFunnels\Stripe\Checkout\Compatibility;

class GooglePay extends AbstractCompatibility {

	protected $id = 'stripe_googlepay';

}