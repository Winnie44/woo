<?php


namespace PaymentPlugins\CartFlows\Stripe;


class Constants {

	const CARTFLOWS_PAYMENT_INTENT_ID = '_cartflows_payment_intent_';
}