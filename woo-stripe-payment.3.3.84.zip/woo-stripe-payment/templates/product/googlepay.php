<?php
/**
 * @var WC_Payment_Gateway_Stripe_GooglePay $gateway
 * @version 3.3.37
 */

?>
<div id="wc-stripe-googlepay-container" class="wc-stripe-googlepay-product-container"></div>