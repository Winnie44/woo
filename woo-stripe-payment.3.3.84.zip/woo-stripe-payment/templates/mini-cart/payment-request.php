<?php
/**
 * @version 3.2.0
 */
?>
<a class="wc-stripe-payment-request-mini-cart" style="display: none"></a>
