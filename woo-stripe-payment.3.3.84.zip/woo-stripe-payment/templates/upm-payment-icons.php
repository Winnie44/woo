<?php

/**
 * @version 3.3.60
 */
foreach ( $icons as $icon ):?>
	<?php echo $icon['icon']; ?>
<?php endforeach; ?>
