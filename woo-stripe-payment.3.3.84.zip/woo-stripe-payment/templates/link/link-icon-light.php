<?php
/**
 * @version 3.3.47
 */

?>
<style>
    .stripe-link-icon-container {
        background-image: url('<?php echo stripe_wc()->assets_url('img/link-icon-light.svg') //phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped?>');
    }
</style>
