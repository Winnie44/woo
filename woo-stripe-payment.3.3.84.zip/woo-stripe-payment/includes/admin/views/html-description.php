<p class="<?php echo $data['class']; ?>"><?php echo wp_kses_post( $data['description'] ); ?></p>
