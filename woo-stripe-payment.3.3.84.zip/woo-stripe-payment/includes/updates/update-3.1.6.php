<?php
/**
 * Schedule actions required by the plugin.
 */
stripe_wc()->scheduled_actions();